function [plato] = PLATO(positiveTS, negativeTS, subLength, groundTruthIndices)
    %%%Ryan Mercer
    %%%Test Version for Eamonn
    %%%2020-11-30
    %%%Requirements: statistics and machine learning (zscore)
    showPlot = true;

    [MP_AA, MP_AA_Indices] = mpx_plato(positiveTS,subLength,subLength);
    MP_AA = real(MP_AA);
    [MP_AB, MP_AB_Indices] = mpx_AB_plato(positiveTS, negativeTS, subLength);
    MP_AB = real(MP_AB);

    minLength = min([length(MP_AA),length(MP_AB)]); %TODO, this is fishy, I think lengths should be the same
    MP_Diff = MP_AB(1:minLength) - MP_AA(1:minLength);

    [shapeletCandidateIndices] = topSubsequenceIndices_V03(MP_Diff, subLength);
    
    shapeletCandidateIndices = shapeletCandidateIndices(1:2);
    
    shapeletCandidateIndices(2) = MP_AA_Indices(shapeletCandidateIndices(1));
    
    queryIndex1 = shapeletCandidateIndices(1);
    queryPart1 = positiveTS(queryIndex1:queryIndex1 + subLength - 1);

    queryIndex2 = shapeletCandidateIndices(2);
    queryPart2 = positiveTS(queryIndex2:queryIndex2 + subLength - 1);

    plato = (zscore(queryPart1) + zscore(queryPart2))/2;
    
    numCandidates = length(shapeletCandidateIndices);
    
%     fileName = "internVars_candidatesVsGroundTruth";
%     filePath = fullfile(figureSavePath, fileName + ".mat");
%     save(filePath, 'shapeletCandidateIndices', 'groundTruthIndices');

    if showPlot == true
        redColor = [0.73,0.05,0];
        greenColor = [0,0.73,0.41]; 
        blueColor = [0,0.29,0.73];
        grayColor = [0.65,0.65,0.65];
        lightBlueColor = [0.01, 0.83,0.99];

        tsLength = length(positiveTS);
        maxTSLength = max(length(positiveTS),length(negativeTS));
        %%% for debugging
        fig = figure; 
        set(gcf, 'Position', [0,100,2050,600]);
        
        tiledlayout(6,1);
        
        ax1 = nexttile;
%         subplot(5,1,1);
        plot(negativeTS);
        formattedTitle = sprintf("Negative Time Series, Length=%d",length(negativeTS));
        title(formattedTitle);
        set(gca,'xtick',[],'ytick',[]);
        xlim([1,maxTSLength]);

        ax2 = nexttile;
%         subplot(5,1,2);
        plot(positiveTS);
        hold on;
        for i = 1:length(groundTruthIndices)
            gti = groundTruthIndices(i);
            %%%TODO: Change the size back to subLength instead of
            %%%2*subLength
            %%% when ground truth is not concatenated
            plot(gti:gti+subLength-1,positiveTS(gti:gti+subLength-1),'Color',greenColor);
        end
        hold off;
        xlim([1,maxTSLength]);
        formattedTitle = sprintf("Positive Time Series, Length=%d",length(positiveTS));
        title(formattedTitle);
        set(gca,'xtick',[],'ytick',[]);
        xlim([1,maxTSLength]);
        
        ax3 = nexttile;
%         subplot(5,1,3);
        plot(MP_AA,'Color',blueColor);
        hold on;
        plot(MP_AB,'Color',redColor);
        xlim([1,maxTSLength]);
        formattedTitle = "\color{redColor}MP_AB, \color{blueColor}MP_AA";
        title(formattedTitle);
        set(gca,'xtick',[],'ytick',[]);

        ax4 = nexttile;
%         subplot(5,1,4);
        plot(MP_Diff,'Color',grayColor);
        hold on;
        scatter(shapeletCandidateIndices, max(MP_Diff)*ones(1,length(shapeletCandidateIndices)),10,'MarkerFaceColor',redColor,'MarkerEdgeColor',redColor,'MarkerFaceAlpha',0.7,'MarkerEdgeAlpha',0); 
        hold off;
        xlim([1,maxTSLength]);
        formattedTitle = sprintf("MP_Diff");
        title(formattedTitle);
        set(gca,'xtick',[],'ytick',[]);
        
        ax5 = nexttile;
%         subplot(5,1,5);
        plot(0,0);
        hold on;
        for gti = groundTruthIndices
            plot([gti,gti],[0,1],'Color',greenColor);
        end
        xlim([1,tsLength]);
        formattedTitle = sprintf("GroundTruth");
        title(formattedTitle);
        set(gca,'xtick',[],'ytick',[]);
        
        ax6 = nexttile;
        distanceProfile = mpx_AB_plato(positiveTS, plato, subLength);
        plot(distanceProfile);
        xlim([1,tsLength]);
        formattedTitle = sprintf("Distance Profile: positiveTS join plato");
        title(formattedTitle);
        set(gca,'xtick',[],'ytick',[]);
        
        linkaxes([ax1 ax2 ax3 ax4 ax5 ax6],'x')
        
        
%         figureFileName = "getFilteredShapeletCandidates";
%         saveas(fig, fullfile(figureSavePath, figureFileName + ".fig"));
%         saveas(fig, fullfile(figureSavePath, figureFileName + ".png"));
%         close(fig);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%% Plot Effectiveness of Candidate Selection %%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        numCandidatesToShow = min(10, length(shapeletCandidateIndices));
        x = zeros(numCandidatesToShow,2*subLength);
        y = zeros(size(x));

        cmappingGlobal = false(1,length(positiveTS));
        for i = 1:length(groundTruthIndices)
            gti = groundTruthIndices(i);
            %%%TODO: Change the size back to subLength instead of
            %%%2*subLength
            %%% when ground truth is not concatenated
            cmappingGlobal(gti:gti+subLength-1) = true;
        end
        
%         fig = figure;
%         plot(0,0);
%         hold on;
%         x = 1:2*subLength;
%         percentGroundTruthInCandidate = zeros(numCandidatesToShow,1);
%         for i = 1:numCandidatesToShow
%             startIndex = shapeletCandidateIndices(i)-ceil(subLength/2);
%             leadingWhiteSpace = max(0,1+ -startIndex);% if startIndex == 0, whitespace = 1
%             startIndex = max(1, startIndex);
%             endIndex = startIndex + subLength - 1 - leadingWhiteSpace;
%             endIndex = min(endIndex, length(positiveTS));
%             displayLength = endIndex - startIndex + 1;
%             
%             y = nan(1,2*subLength);
%             y(1+leadingWhiteSpace:1+leadingWhiteSpace + displayLength - 1) = positiveTS(startIndex:endIndex);
%             cmapping = zeros(1,2*subLength);
%             cmapping(1+leadingWhiteSpace:1+leadingWhiteSpace + displayLength - 1) = cmappingGlobal(startIndex:endIndex);
%             
%             %%% For accuracy reporting, not plotting
%             cmappingTrueLength = cmappingGlobal(shapeletCandidateIndices(i): shapeletCandidateIndices(i) + subLength-1);
%             percentGroundTruthInCandidate(i) = sum(cmappingTrueLength)/subLength;
%             
%             tempMin = min(y);
%             tempMax = max(y);
%             tempRange = max(1e-5, (tempMax-tempMin));
% 
%             xfalse = x;
%             xtrue = x;
% 
%             xfalse(cmapping == true) = nan;
%             xtrue(~cmapping == true) = nan;
% 
%             yfalse = y;
%             ytrue = y;
% 
%             yfalse(cmapping == true) = nan;
%             ytrue(~cmapping == true) = nan;
% 
%             plot(xfalse,1-i+0.95*(yfalse-tempMin)/tempRange,'Color',[0.5,0.5,0.5]);
%             plot(xtrue,1-i+0.95*(ytrue-tempMin)/tempRange,'Color',[0,0.8,0.2]);
%             gti = find(cmapping,1);
%             if gti
%                 scatter(gti,1-i+0.95*(ytrue(gti)-tempMin)/tempRange,10,'MarkerFaceColor',[0,0.8,0.2], 'MarkerEdgeAlpha',0);
%             end
%            
%         end
%         xlim([1,2*subLength]);
%         r = rectangle();
%         r.Position = [1, 1-i, ceil(size(x,2)/4), numCandidatesToShow];
%         r.FaceColor = [1,1,1, 0.45];
%         r.LineStyle = '--';
%         r.EdgeColor = [0,0,0, 0.45];
% 
%         r = rectangle();
%         r.Position = [ceil(size(x,2)/4)*3, 1-i, ceil(size(x,2)/4), numCandidatesToShow];
%         r.FaceColor = [1,1,1, 0.45];
%         r.LineStyle = '--';
%         r.EdgeColor = [0,0,0, 0.45];
%         hold off;
%         
%         legendLabels = {};
%         legendMarkers = [];
%         for i = 1:length(percentGroundTruthInCandidate)
%             value = 100* percentGroundTruthInCandidate(i);
%             legendLabels{end+1} = sprintf('%.1f%%',value);
%             legendMarkers(end+1) = line(nan, nan, 'Linestyle', 'none', 'Marker', '.', 'Color', 'none');
%         end
%         
%         legend(legendMarkers,legendLabels);
%         formattedTitle = sprintf("MP-Diff Candidate Selection Performance");
%         title(formattedTitle);
%         set(gca,'xtick',[],'ytick',[]);

        %%%%%%%%%%%%%%%%%%
        %%% PLATO plot %%%
        %%%%%%%%%%%%%%%%%%
        subsequences = zeros(sum(~isnan(shapeletCandidateIndices)),subLength);
        for i=1:sum(~isnan(shapeletCandidateIndices))
            subsequences(i,:) = positiveTS(shapeletCandidateIndices(i):shapeletCandidateIndices(i)+subLength - 1);
        end


        fig = figure;
        set(gcf, 'Position', [0,100,600,200]);
        % subplot(10,1,[1,9]);
        plot(0,0); hold on;
        inset = 0.9;
        pi = 0;
        for i = 0:length(shapeletCandidateIndices)
            
            
            if i == 0%queryPosIndex
                lineWidth = 5;
                tempTS = plato;
                plot([1,length(plato)],[-0.05,-0.05],'--','Color',[0.8,0.8,0.8]);
            else
                lineWidth = 1;
                ti = shapeletCandidateIndices(i);
                tempTS = positiveTS(ti:ti+subLength-1);
            end
            
            tempMin = min(tempTS);
            tempMax = max(tempTS);
            tempRange = max(1e-5, tempMax-tempMin);

            plot(-pi+inset*(tempTS-tempMin)/tempRange,'LineWidth',lineWidth);

            pi = pi + 1;
        end
        hold off;
        xlim([0,subLength]);
        formattedTitle = sprintf("PLATO and Candidate Subsequences. PLATO = mean(top1, top1NN), Length=%d",length(subLength));
        title(formattedTitle);
        set(gca,'xtick',[],'ytick',[]);

    end
end


function [mp,mpi] = mpx_plato(a,minlag,w)
% a is time series
% minlag is the exclusion zone
% w is the window size
% matrix profile using cross correlation,

% depends on files sum2s, musigtest, dot2s
n = length(a);
[mu, sig] = muinvn(a,w);


% differentials have 0 as their first entry. This simplifies index
% calculations slightly and allows us to avoid special "first line"
% handling.
df = [0; (1/2)*(a(1+w:n)-a(1:n-w))];
dg = [0; (a(1+w:n) - mu(2:n-w+1)) + (a(1:n-w)-mu(1:n-w))];
diagmax = length(a)-w+1;
mp = repmat(-1,n-w+1,1);
mpi = NaN(n-w+1,1);

for diag = minlag+1:diagmax
    c = (sum((a(diag:diag+w-1)-mu(diag)).*(a(1:w)-mu(1))));
    for offset = 1:n-w-diag+2
        c = c + df(offset)*dg(offset+diag-1) + df(offset+diag-1)*dg(offset);
        c_cmp = c*(sig(offset)*sig(offset+diag-1));
        if c_cmp > mp(offset)

            mp(offset) = c_cmp;
            mpi(offset) = offset+diag-1;
        end
        if c_cmp > mp(offset+diag-1)
            mp(offset+diag-1) = c_cmp;
            mpi(offset+diag-1) = offset;
        end
    end
end
% to do ed
% mp = mp;
mp = 1-max(0,mp);

% mp = sqrt(2*w*(1-mp));
% mp = mp/sqrt(2*w);

% mp = 2*w*(1-mp)/(w*log(w));

end

% Functions here are based on the work in
% Ogita et al, Accurate Sum and Dot Product

function [mu,sig] = muinvn(a,w)
% results here are a moving average and stable inverse centered norm based
% on Accurate Sum and Dot Product, Ogita et al


mu = sum2s(a,w)./w;
sig = zeros(length(a) - w + 1, 1);

for i = 1:length(mu)
    sig(i) = sq2s(a(i : i + w - 1) - mu(i));
end

sig = 1./sqrt(sig);
end


function res = sq2s(a)
h = a .* a;
c = ((2^27) + 1) * a;  % <-- can be replaced with fma where available
a1 = (c - (c - a));
a2 = a - a1;
a3 = a1 .* a2;
r = a2 .* a2 - (((h - a1 .* a1) - a3) - a3);
p = h(1);
s = r(1);
for i = 2 : length(a)
    x = p + h(i);
    z = x - p;
    s = s + (((p - (x - z)) + (h(i) - z)) + r(i));
    p = x;
end
res = p + s;
end


function [x,y] = TwoSquare(a)
x = a .* a;
c = ((2^27) + 1) .* a;
a1 = (c - (c - a));
a2 = a - a1;
a3 = a1 .* a2;
y = a2 .* a2 - (((x - a1 .* a1) - a3) - a3);
end

function [ res ] = sum2s(a,w)
res = zeros(length(a) - w + 1, 1);
p = a(1);
s = 0;
for i = 2 : w
    x = p + a(i);
    z = x - p;
    s = s + ((p - (x - z)) + (a(i) - z));
    p = x;
end
res(1) = p + s;
for i = w + 1 : length(a)
    x = p - a(i - w);
    z = x - p;
    s = s + ((p - (x - z)) - (a(i - w) + z));
    p = x;

    x = p + a(i);
    z = x - p;
    s = s + ((p - (x - z)) + (a(i) - z));
    p = x;

    res(i - w + 1) = p + s;
end
end

function [ res ] = sum2s_v2(a,w)
res = zeros(length(a) - w + 1, 1);
accum = a(1);
resid = 0;
for i = 2 : w
    m = a(i);
    p = accum;
    accum = accum + m;
    q = accum - p;
    resid = resid + ((p - (accum - q)) + (m - q));
end
res(1) = accum + resid;
for i = w + 1 : length(a)
    m = a(i - w);
    n = a(i);
    p = accum - m;
    q = p - accum;
    r = resid + ((accum - (p - q)) - (m + q));
    accum = p + n;
    t = accum - p;
    resid = r + ((p - (accum - t)) + (n - t));
    res(i - w + 1) = accum + resid;
end
end


function [mp, mpi] = mpx_AB_plato(a, b, w)

% matrix profile using cross correlation,
% updated to use the function muinvn, which is a nicer implementation of my
% take on Ogita's work

[mua, invna] = muinvn(a,w);
[mub, invnb] = muinvn(b,w);

% differentials have 0 as their first entry. This simplifies index
% calculations slightly and allows us to avoid special "first line"
% handling.

df = [0; (1/2)*(a(1 + w : end) - a(1 : end - w))];
dg = [0; (a(1 + w : end) - mua(2 : end)) + (a(1 : end - w) - mua(1 : end - 1))];
dx = [0; (1/2)*(b(1 + w : end) - b(1 : end - w))];
dy = [0; (b(1 + w : end) - mub(2 : end)) + (b(1 : end - w) - mub(1 : end - 1))];

amx = length(a) - w + 1;
bmx = length(b) - w + 1;
mp = repmat(-1, amx, 1);
mpi = NaN(amx, 1);

for ia = 1 : amx
    mx = min(amx - ia + 1, bmx);
    c = sum((a(ia : ia + w - 1) - mua(ia)) .* (b(1 : w) - mub(1)));
    for ib = 1 : mx
        c = c + df(ib + ia - 1) * dy(ib) + dg(ib + ia - 1) * dx(ib);
        c_cmp = c * invna(ib + ia - 1) * invnb(ib);
        if c_cmp > mp(ib + ia - 1)
            mp(ib + ia - 1) = c_cmp;
            mpi(ib + ia - 1) = ib;
        end
    end
end

for ib = 1 : bmx
    mx = min(bmx - ib + 1, amx);
    c = sum((b(ib : ib + w - 1) - mub(ib)) .* (a(1 : w) - mua(1)));
    for ia = 1 : mx
        c = c + df(ia) * dy(ib + ia - 1) + dg(ia) * dx(ib + ia - 1);
        c_cmp = c * invna(ia) * invnb(ib + ia - 1);
        if c_cmp > mp(ia)
            mp(ia) = c_cmp;
            mpi(ia) = ia + ib - 1;
        end
    end
end
if(any(mp > 1))
    warning('possible precision loss due to rounding');
end
% mp = sqrt(2 * w * (1 - min(1, mp, 'includenan')));
% mp = max(0,sqrt(1 - min(1, mp, 'includenan')));
% mp = max(0,sqrt(1-mp));

mp = 1-max(0, min(1, mp, 'includenan'),'includenan');
end

function [topIndices] = topSubsequenceIndices_V03(ts, subsequenceLength)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

exclusionLength = ceil(subsequenceLength);
N = 2*floor(length(ts)/(subsequenceLength));

A = zeros(2,length(ts));
A(1,:) = 1:length(ts);
A(2,:) = ts';
A = A';
B = flip(sortrows(A,2),1);

exclusionZone = zeros(1,length(ts));

topIndices = nan(1,N);
index = 1;
iterNum = 1; %for debugging
while index <= N && iterNum < size(B,1)
    trialIndex = B(iterNum,1);
    if exclusionZone(trialIndex) == 0
        topIndices(index) = trialIndex;
        index = index + 1;
        leftOffset = exclusionLength;
        rightOffset = exclusionLength;
        exclusionZone(max(1,trialIndex - leftOffset):min(length(ts), trialIndex + rightOffset)) = 1;
    end
    iterNum = iterNum + 1;
end

topIndices = topIndices(~isnan(topIndices));
end

