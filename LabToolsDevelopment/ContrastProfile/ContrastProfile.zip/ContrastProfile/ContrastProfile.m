function [tp, fp] = ContrastProfile(PLATO, ts, K, weakLabels)

%%
%Inputs:
% query, PLATO
% test time series, ts
% parameter to select lowest distance candidates, K
% user's domain knowledge (binary label vector), weakLabels
%Outputs:
% Number of true positive and false positives, tp, fp

%%
subLength = length(PLATO);

% Query test set to get distances
distanceProfile = MASS_V4(ts, PLATO);
% Choose Top K
bestIndices = KLowestDistanceIndices_V05(distanceProfile, subLength, K);
binaryTopK = zeros(1,length(distanceProfile));
binaryTopK(bestIndices) = 1;

% plot
figure;
hold on;
plot(binaryTopK);
plot(weakLabels);
plot(bitand(binaryTopK,weakLabels));

% Evaluate
tp = sum(bitand(binaryTopK,weakLabels));
fp = sum(binaryTopK) - sum(bitand(binaryTopK,weakLabels));


end
