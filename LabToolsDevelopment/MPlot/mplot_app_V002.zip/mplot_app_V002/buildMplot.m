function buildMplot(timeseries)
    tool = mplotclass;
    startup(tool, timeseries);
    %plotMplot(tool);
end